create view pg_stat_all_indexes
            (relid, indexrelid, schemaname, relname, indexrelname, idx_scan, last_idx_scan, idx_tup_read,
             idx_tup_fetch) as
SELECT c.oid                              AS relid,
       i.oid                              AS indexrelid,
       n.nspname                          AS schemaname,
       c.relname,
       i.relname                          AS indexrelname,
       pg_stat_get_numscans(i.oid)        AS idx_scan,
       pg_stat_get_lastscan(i.oid)        AS last_idx_scan,
       pg_stat_get_tuples_returned(i.oid) AS idx_tup_read,
       pg_stat_get_tuples_fetched(i.oid)  AS idx_tup_fetch
FROM pg_class c
         JOIN pg_index x ON c.oid = x.indrelid
         JOIN pg_class i ON i.oid = x.indexrelid
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind = ANY (ARRAY ['r'::"char", 't'::"char", 'm'::"char"]);

alter table pg_stat_all_indexes
    owner to delivery;

grant select on pg_stat_all_indexes to public;

