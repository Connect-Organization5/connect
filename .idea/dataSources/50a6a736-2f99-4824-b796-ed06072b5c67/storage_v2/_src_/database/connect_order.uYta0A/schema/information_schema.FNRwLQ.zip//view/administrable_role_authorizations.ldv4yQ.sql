create view administrable_role_authorizations(grantee, role_name, is_grantable) as
SELECT grantee,
       role_name,
       is_grantable
FROM information_schema.applicable_roles
WHERE is_grantable::text = 'YES'::text;

alter table administrable_role_authorizations
    owner to delivery;

grant select on administrable_role_authorizations to public;

