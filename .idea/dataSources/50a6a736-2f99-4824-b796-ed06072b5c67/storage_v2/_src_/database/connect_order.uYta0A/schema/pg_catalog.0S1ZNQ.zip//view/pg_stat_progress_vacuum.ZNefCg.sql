create view pg_stat_progress_vacuum
            (pid, datid, datname, relid, phase, heap_blks_total, heap_blks_scanned, heap_blks_vacuumed,
             index_vacuum_count, max_dead_tuple_bytes, dead_tuple_bytes, num_dead_item_ids, indexes_total,
             indexes_processed, delay_time)
as
SELECT s.pid,
       s.datid,
       d.datname,
       s.relid,
       CASE s.param1
           WHEN 0 THEN 'initializing'::text
           WHEN 1 THEN 'scanning heap'::text
           WHEN 2 THEN 'vacuuming indexes'::text
           WHEN 3 THEN 'vacuuming heap'::text
           WHEN 4 THEN 'cleaning up indexes'::text
           WHEN 5 THEN 'truncating heap'::text
           WHEN 6 THEN 'performing final cleanup'::text
           ELSE NULL::text
           END                                                 AS phase,
       s.param2                                                AS heap_blks_total,
       s.param3                                                AS heap_blks_scanned,
       s.param4                                                AS heap_blks_vacuumed,
       s.param5                                                AS index_vacuum_count,
       s.param6                                                AS max_dead_tuple_bytes,
       s.param7                                                AS dead_tuple_bytes,
       s.param8                                                AS num_dead_item_ids,
       s.param9                                                AS indexes_total,
       s.param10                                               AS indexes_processed,
       s.param11::double precision / 1000000::double precision AS delay_time
FROM pg_stat_get_progress_info('VACUUM'::text) s(pid, datid, relid, param1, param2, param3, param4, param5, param6,
                                                 param7, param8, param9, param10, param11, param12, param13, param14,
                                                 param15, param16, param17, param18, param19, param20)
         LEFT JOIN pg_database d ON s.datid = d.oid;

alter table pg_stat_progress_vacuum
    owner to delivery;

grant select on pg_stat_progress_vacuum to public;

